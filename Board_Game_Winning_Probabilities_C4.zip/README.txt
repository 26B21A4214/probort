# Board Game Winning Probabilities (C4)

Open `Board_Game_Winning_Probabilities_C4.ipynb` in Google Colab.

## How to use
1. Upload the `.ipynb` file to Google Colab.
2. Run the cells from top to bottom.
3. Edit the transition matrix `T`, initial distribution, and number of turns in Cell 2 if needed.
4. The notebook calculates T^50, diagonalization, winning probability, expected turns, and charts.

## Assumption
The transition matrix is row-stochastic and State 4 is an absorbing winning state.

## Main mathematics
p_(k+1) = p_k T
p_k = p_0 T^k
T = P D P^-1
T^50 = P D^50 P^-1
Expected hitting time: (I-Q)E = 1
